
package Funcoes;
/*

NUMEROS NO  | VALOR DA     | EQUIVALE A <n> 
BILHETE     | APOSTA       | APOSTAS de 6 números
------------+--------------+------------------------          
6 números   | R$ 3,50      |    1 aposta 
7 números   | R$ 24,50     |    7 apostas 
8 números   | R$ 98,00     |   28 apostas 
9 números   | R$ 294,00    |   84 apostas 
10 números  | R$ 735,00    |  210 apostas 
11 números  | R$ 1617,00   |  462 apostas 
12 números  | R$ 3234,00   |  924 apostas 
13 números  | R$ 6006,00   | 1716 apostas 
14 números  | R$ 10510,50  | 3003 apostas 
15 números  | R$ 17517,50  | 5005 apostas

*/

public class Apostas {
    
    public static void quina() {
        System.out.println("Quina");
    }
    
    public static void sena() {
        System.out.println("Sena");
    }
    
    
     public static void duplaSena() {
        System.out.println("Dupla Sena");
    }
     
      public static void lotoFacil() {
        System.out.println("Loto Facil");
    }  
      
      public static void geradorDeJogos() {
        
    }
      
      public static void geradorRandom(int numero){
        //Math.random() gera um número aleatório entre 0.0 e 0.999
        // Assim, Math.random()*5 estará entre 0.0 e 4.999
        double doubleRandomNumber = Math.random() * numero;
        System.out.println("doubleRandomNumber = " + doubleRandomNumber);
        // fazer o casting do número para um número inteiro
        int randomNumber = (int)doubleRandomNumber;
        System.out.println("randomNumber = " + randomNumber);
    }
    /* Resultado nº1
    doubleRandomNumber = 2.431392914284627
    randomNumber = 2
      }
*/
    
}
