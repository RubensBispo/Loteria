
package Model;

import java.util.Random;
import javax.swing.JOptionPane;

public class Jogo_DAO {
    public static String total ="";
    public static Random ale = new Random();
    public static int c=0;
    public static long [] valor = new long[15];
    
    public static void quina(){
        
        for(c =0 ; c< 5; c++){
           valor[c] = ale.nextInt(+80)-(-1);
           total = total + valor[c] + " | ";
        }
      
        JOptionPane.showMessageDialog(null, total);
    }
    
     public static void sena(){
        
        for(c =0 ; c< 6; c++){
           valor[c] = ale.nextInt(+80)-(-1);
           total = total + valor[c] + " | ";
        }
      
        JOptionPane.showMessageDialog(null, total);
    }
    
     public static void duplasena(){
        
        for(c =0 ; c< 12; c++){
           valor[c] = ale.nextInt(+80)-(-1);
           total = total + valor[c] + " | ";
           if(c == 5){
               total = total + "\n\n";
           }
        }
      
        JOptionPane.showMessageDialog(null, total);
    }
    
     public static void lotofacil(){
        
        for(c =0 ; c< 15; c++){
           valor[c] = ale.nextInt(+25)-(-1);
           total = total + valor[c] + " | ";
           if(c ==  4 || c == 9){
               total = total + "\n";
           }
        }
      
        JOptionPane.showMessageDialog(null, total);
    }
}
