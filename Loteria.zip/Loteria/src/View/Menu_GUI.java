package View;

import Funcoes.Apostas;
import javax.swing.JOptionPane;


public class Menu_GUI {
  public static int op = 0;
   public static String x = "";
   
   
    public static void menu(){
       
       
       while(op != 5){
          
           x = JOptionPane.showInputDialog(null,"1-Quina\n2-Sena\n3-Dupla Sena\n4-Lotomania\n5-Sair");
           op = Integer.parseInt(x);
          
           if(op ==1){
              Model.Jogo_DAO.quina();
           }else if(op ==2){
               Model.Jogo_DAO.sena();
           }else if(op ==3){
               Model.Jogo_DAO.duplasena();
           }else if(op ==4){
               Model.Jogo_DAO.lotofacil();
           }else if(op ==5){
               JOptionPane.showMessageDialog(null, "Até mais...");
           }else{
               JOptionPane.showMessageDialog(null, "Opção Inválida");
           }
          
       }
       
       
    }
}
